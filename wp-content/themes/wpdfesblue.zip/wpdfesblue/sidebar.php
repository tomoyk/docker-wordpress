<div class="large-4 columns side-bar">
	<?php dynamic_sidebar(); ?>
</div>