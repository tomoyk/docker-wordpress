		<div class="row">
			<div class="large-6 columns">
				<?php dynamic_sidebar('footer01'); ?>
			</div>
			<div class="large-6 columns">
				<?php dynamic_sidebar('footer02'); ?>
			</div>
		</div>
		<div class="row">
			<div class="large-12 columns text-center">
				<hr>
				<p>copyright</p>
				<p>Photo by <a href="http://www.flickr.com/photos/fergusonphotography/">jerryfergusonphotography</a> and <a href="http://www.flickr.com/photos/dougtone/"> Dougtone</a></p>
			</div>
		</div>
		<a id="pageTop" href="#top">▲TOP</a>
		<?php wp_footer(); ?>
	</body>
</html>
